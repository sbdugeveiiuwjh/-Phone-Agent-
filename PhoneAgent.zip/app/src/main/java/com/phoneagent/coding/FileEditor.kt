package com.phoneagent.coding

import android.content.Context
import java.io.File

/** Bolke coding/editing: sab kuch ek "workspace" folder ke andar (safe sandbox). */
class FileEditor(ctx: Context) {
    private val root: File =
        (ctx.getExternalFilesDir("workspace") ?: File(ctx.filesDir, "workspace"))
            .apply { mkdirs() }.canonicalFile

    private fun resolve(path: String): File {
        val f = File(root, path).canonicalFile
        require(f.path.startsWith(root.path)) { "Path workspace ke bahar hai" }
        return f
    }

    fun exists(path: String) = resolve(path).exists()

    fun list(): String {
        val files = root.walkTopDown().filter { it.isFile }.take(200)
            .joinToString("\n") { it.relativeTo(root).path }
        return files.ifBlank { "(workspace khali hai) path: ${root.path}" }
    }

    fun read(path: String): String {
        val f = resolve(path)
        return if (f.isFile) f.readText().take(12000) else "File nahi mili: $path"
    }

    fun write(path: String, content: String): String {
        val f = resolve(path)
        f.parentFile?.mkdirs()
        f.writeText(content)
        return "Likh diya: $path (${content.length} chars)"
    }

    fun edit(path: String, old: String, new: String): String {
        val f = resolve(path)
        if (!f.isFile) return "File nahi mili: $path"
        if (old.isEmpty()) return "old_text khali nahi ho sakta"
        val text = f.readText()
        val count = text.split(old).size - 1
        if (count == 0) return "old_text file me nahi mila"
        if (count > 1) return "old_text $count baar mila, thoda aur specific do"
        f.writeText(text.replace(old, new))
        return "Edit ho gaya: $path"
    }
}
