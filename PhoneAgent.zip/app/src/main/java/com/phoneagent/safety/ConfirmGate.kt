package com.phoneagent.safety

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow

/** Risky kaam (pay, send, delete, call...) se pehle user se permission. */
object ConfirmGate {
    val pending = MutableStateFlow<String?>(null)
    private var deferred: CompletableDeferred<Boolean>? = null

    suspend fun confirm(message: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        deferred = d
        pending.value = message
        return d.await()
    }

    fun answer(ok: Boolean) {
        pending.value = null
        deferred?.complete(ok)
        deferred = null
    }
}
