package com.phoneagent.control

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock

object SystemActions {
    private fun go(ctx: Context, i: Intent): String {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "ok"
    }

    fun dial(ctx: Context, number: String) =
        go(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))

    fun sms(ctx: Context, number: String, message: String) =
        go(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", message))

    fun alarm(ctx: Context, hour: Int, minute: Int, label: String) =
        go(
            ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )

    fun url(ctx: Context, url: String) =
        go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}
