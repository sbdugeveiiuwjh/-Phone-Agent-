package com.phoneagent.control

import android.content.Context
import android.content.Intent

object AppLauncher {
    fun open(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)
        val q = name.lowercase().trim()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "App nahi mila: $name"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "App launch nahi ho sakta: $name"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return "Khul gaya: ${match.loadLabel(pm)}"
    }
}
