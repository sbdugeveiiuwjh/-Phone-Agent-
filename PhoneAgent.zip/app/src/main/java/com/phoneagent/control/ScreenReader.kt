package com.phoneagent.control

import android.view.accessibility.AccessibilityNodeInfo

/** Screen ke elements ko numbered list me badalta hai, taaki AI "tap [5]" bol sake. */
object ScreenReader {
    private var nodes: List<AccessibilityNodeInfo> = emptyList()
    private var labels: List<String> = emptyList()

    fun snapshot(service: AgentAccessibilityService): String {
        val root = service.rootInActiveWindow ?: return "Screen abhi available nahi hai"
        val list = mutableListOf<AccessibilityNodeInfo>()
        val names = mutableListOf<String>()
        val sb = StringBuilder("App: ${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || !n.isVisibleToUser) return
            val label = (n.text ?: n.contentDescription)?.toString()?.take(80) ?: ""
            val useful = label.isNotBlank() || n.isClickable || n.isEditable || n.isScrollable
            if (useful) {
                val flags = mutableListOf<String>()
                if (n.isClickable) flags.add("tap")
                if (n.isEditable) flags.add("input")
                if (n.isScrollable) flags.add("scroll")
                sb.append("[${list.size}] $label (${flags.joinToString(",")})\n")
                list.add(n)
                names.add(label)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        nodes = list
        labels = names
        return sb.toString().take(6000)
    }

    fun get(index: Int): AccessibilityNodeInfo? = nodes.getOrNull(index)
    fun label(index: Int): String = labels.getOrNull(index) ?: ""
    fun firstScrollable(): AccessibilityNodeInfo? = nodes.firstOrNull { it.isScrollable }
}
