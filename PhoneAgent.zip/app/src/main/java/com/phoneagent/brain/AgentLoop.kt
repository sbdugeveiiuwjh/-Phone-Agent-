package com.phoneagent.brain

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Plan -> action -> check loop. Claude tool batata hai, hum chalate hain, result wapas bhejte hain. */
class AgentLoop(
    private val ctx: Context,
    private val client: ClaudeClient,
    private val onLog: (String) -> Unit
) {
    private val history = JSONArray()

    companion object {
        const val MAX_STEPS = 25
        const val SYSTEM = """Tum ek Android phone control agent ho. User Hindi/Hinglish me bolta hai; usi bhasha me chhota jawab do.
Rules:
- Phone ka kaam karne se pehle read_screen se dekho, phir ek-ek step lo, har step ke baad read_screen se check karo.
- Pehle open_app/open_url/set_alarm jaise seedhe tools use karo, phir tap/type_text/scroll.
- Coding ya editing ho to workspace ki files (list_files, read_file, write_file, edit_file) me kaam karo. Chhote badlav ke liye edit_file use karo.
- Payment, delete, message bhejna jaise kaam ke liye app khud user se permission puchhega; mana ho to ruk jao.
- Kaam ho jaye ya aage na badh pao to saaf batao ki kya hua."""
    }

    suspend fun run(userText: String): String {
        history.put(JSONObject().put("role", "user").put("content", userText))
        repeat(MAX_STEPS) {
            val resp = client.send(SYSTEM, Tools.definitions, history)
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))

            if (resp.optString("stop_reason") != "tool_use") {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.getString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().ifBlank { "Ho gaya." }
            }

            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.getString("type") != "tool_use") continue
                val name = b.getString("name")
                val input = b.getJSONObject("input")
                onLog("▶ $name ${input.toString().take(80)}")
                val out = Tools.execute(ctx, name, input)
                results.put(
                    JSONObject().put("type", "tool_result")
                        .put("tool_use_id", b.getString("id"))
                        .put("content", out)
                )
            }
            history.put(JSONObject().put("role", "user").put("content", results))
            trimOld()
        }
        return "Step limit (${MAX_STEPS}) tak pahunch gaya. Dobara bolo to main aage badhunga."
    }

    /** Purane bade screen snapshots hata deta hai taaki tokens bachein. */
    private fun trimOld() {
        var seen = 0
        for (i in history.length() - 1 downTo 0) {
            val m = history.getJSONObject(i)
            val c = m.opt("content")
            if (m.getString("role") == "user" && c is JSONArray) {
                seen++
                if (seen > 2) {
                    for (j in 0 until c.length()) {
                        val b = c.getJSONObject(j)
                        if (b.optString("type") == "tool_result" && b.optString("content").length > 300) {
                            b.put("content", "[purana output hata diya]")
                        }
                    }
                }
            }
        }
    }
}
