package com.phoneagent.brain

import android.content.Context
import com.phoneagent.coding.FileEditor
import com.phoneagent.control.AgentAccessibilityService
import com.phoneagent.control.AppLauncher
import com.phoneagent.control.ScreenReader
import com.phoneagent.control.SystemActions
import com.phoneagent.safety.ConfirmGate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

object Tools {
    private const val NEED_A11Y =
        "Accessibility service ON nahi hai. User se kaho: Settings > Accessibility > Phone Agent ON kare."

    private val risky = Regex(
        "pay|buy|purchase|order|send|delete|remove|transfer|uninstall|confirm|submit|checkout|place|call|dial|भेज|हटा|खरीद|भुगतान|कॉल",
        RegexOption.IGNORE_CASE
    )

    private fun strP(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun intP(d: String) = JSONObject().put("type", "integer").put("description", d)

    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), req: List<String> = emptyList()) =
        JSONObject().put("name", name).put("description", desc)
            .put(
                "input_schema",
                JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req))
            )

    val definitions: JSONArray = JSONArray()
        .put(tool("read_screen", "Current screen ke elements ki numbered list deta hai. Har action se pehle/baad me use karo."))
        .put(tool("open_app", "App ko naam se kholo.", JSONObject().put("name", strP("App ka naam")), listOf("name")))
        .put(tool("tap", "read_screen ke index par tap karo.", JSONObject().put("index", intP("Element index")), listOf("index")))
        .put(
            tool(
                "type_text", "Input field me text likho.",
                JSONObject().put("index", intP("Input element index")).put("text", strP("Likhne wala text")),
                listOf("index", "text")
            )
        )
        .put(tool("scroll", "Screen scroll karo.", JSONObject().put("direction", strP("down ya up")), listOf("direction")))
        .put(tool("press", "System button: back, home, recents, notifications.", JSONObject().put("button", strP("back|home|recents|notifications")), listOf("button")))
        .put(tool("open_url", "Browser me URL kholo.", JSONObject().put("url", strP("Poora URL")), listOf("url")))
        .put(tool("dial", "Dialer me number kholo.", JSONObject().put("number", strP("Phone number")), listOf("number")))
        .put(
            tool(
                "send_sms", "SMS composer kholo (message pehle se bhara hua).",
                JSONObject().put("number", strP("Number")).put("message", strP("Message")), listOf("number", "message")
            )
        )
        .put(
            tool(
                "set_alarm", "Alarm set karo.",
                JSONObject().put("hour", intP("0-23")).put("minute", intP("0-59")).put("label", strP("Label")),
                listOf("hour", "minute")
            )
        )
        .put(tool("list_files", "Workspace ki files dikhao."))
        .put(tool("read_file", "Workspace ki file padho.", JSONObject().put("path", strP("Relative path")), listOf("path")))
        .put(
            tool(
                "write_file", "Workspace me nayi file likho (ya purani overwrite).",
                JSONObject().put("path", strP("Relative path")).put("content", strP("Poora content")),
                listOf("path", "content")
            )
        )
        .put(
            tool(
                "edit_file", "File me ek exact text ko naye text se badlo.",
                JSONObject().put("path", strP("Relative path")).put("old_text", strP("Exact purana text"))
                    .put("new_text", strP("Naya text")),
                listOf("path", "old_text", "new_text")
            )
        )
        .put(tool("wait", "Kuch second ruko.", JSONObject().put("seconds", intP("1-10")), listOf("seconds")))

    suspend fun execute(app: Context, name: String, input: JSONObject): String =
        withContext(Dispatchers.IO) {
            val svc = AgentAccessibilityService.instance
            val ctx: Context = svc ?: app
            val files = FileEditor(app)
            try {
                when (name) {
                    "read_screen" -> if (svc == null) NEED_A11Y else ScreenReader.snapshot(svc)

                    "open_app" -> {
                        val r = AppLauncher.open(ctx, input.getString("name"))
                        delay(1500); r
                    }

                    "tap" -> {
                        val s = svc ?: return@withContext NEED_A11Y
                        val i = input.getInt("index")
                        val label = ScreenReader.label(i)
                        if (risky.containsMatchIn(label) &&
                            !ConfirmGate.confirm("Agent is par tap karna chahta hai: \"$label\"\nAllow?")
                        ) {
                            "User ne mana kar diya"
                        } else {
                            val ok = s.tap(i)
                            delay(1200)
                            if (ok) "Tap ho gaya [$i] $label"
                            else "Tap fail. read_screen dobara chalao."
                        }
                    }

                    "type_text" -> {
                        val s = svc ?: return@withContext NEED_A11Y
                        val ok = s.typeText(input.getInt("index"), input.getString("text"))
                        delay(600)
                        if (ok) "Text likh diya" else "Type fail. Sahi input index check karo."
                    }

                    "scroll" -> {
                        val s = svc ?: return@withContext NEED_A11Y
                        val ok = s.scroll(input.getString("direction") == "down")
                        delay(800)
                        if (ok) "Scroll ho gaya" else "Scroll karne layak kuch nahi mila"
                    }

                    "press" -> {
                        val s = svc ?: return@withContext NEED_A11Y
                        val ok = s.press(input.getString("button"))
                        delay(800)
                        if (ok) "Dabaya" else "Button fail"
                    }

                    "open_url" -> { SystemActions.url(ctx, input.getString("url")); delay(1500); "URL khul gaya" }

                    "dial" -> {
                        val n = input.getString("number")
                        if (!ConfirmGate.confirm("Dialer me $n kholna hai?")) "User ne mana kar diya"
                        else { SystemActions.dial(ctx, n); delay(1000); "Dialer khul gaya" }
                    }

                    "send_sms" -> {
                        SystemActions.sms(ctx, input.getString("number"), input.getString("message"))
                        delay(1200)
                        "SMS composer khul gaya. Send button par tap karna hoga (wo permission puchega)."
                    }

                    "set_alarm" -> {
                        SystemActions.alarm(
                            ctx, input.getInt("hour"), input.getInt("minute"), input.optString("label", "Alarm")
                        )
                        "Alarm set kar diya"
                    }

                    "list_files" -> files.list()
                    "read_file" -> files.read(input.getString("path"))

                    "write_file" -> {
                        val p = input.getString("path")
                        if (files.exists(p) && !ConfirmGate.confirm("File overwrite karni hai: $p ?")) "User ne mana kar diya"
                        else files.write(p, input.getString("content"))
                    }

                    "edit_file" -> files.edit(
                        input.getString("path"), input.getString("old_text"), input.getString("new_text")
                    )

                    "wait" -> { delay(input.getInt("seconds").coerceIn(1, 10) * 1000L); "Ruk gaya" }

                    else -> "Unknown tool: $name"
                }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        }
}
