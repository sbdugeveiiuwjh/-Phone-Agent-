package com.phoneagent.brain

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ClaudeClient(
    private val apiKey: () -> String,
    private val model: () -> String
) {
    private val http = OkHttpClient.Builder()
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    suspend fun send(system: String, tools: JSONArray, messages: JSONArray): JSONObject =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put("model", model())
                .put("max_tokens", 1024)
                .put("system", system)
                .put("tools", tools)
                .put("messages", messages)
            val req = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .header("x-api-key", apiKey())
                .header("anthropic-version", "2023-06-01")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("API ${r.code}: ${text.take(300)}")
                JSONObject(text)
            }
        }
}
