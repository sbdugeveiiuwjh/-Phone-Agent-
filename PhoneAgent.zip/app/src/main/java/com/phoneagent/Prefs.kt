package com.phoneagent

import android.content.Context

object Prefs {
    const val DEFAULT_MODEL = "claude-sonnet-5-5"

    private fun sp(c: Context) = c.getSharedPreferences("agent", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("key", v.trim()).apply()

    fun model(c: Context): String = sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim()).apply()
}
