package com.phoneagent.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class SpeechOutput(ctx: Context) {
    private var ready = false
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("hi", "IN")
                ready = true
            }
        }
    }

    fun speak(text: String) {
        if (ready) tts.speak(text.take(400), TextToSpeech.QUEUE_FLUSH, null, "agent")
    }
}
