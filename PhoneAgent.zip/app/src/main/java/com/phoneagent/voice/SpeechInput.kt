package com.phoneagent.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Bolna -> text. Main thread par chalana zaroori hai. */
class SpeechInput(private val ctx: Context) {
    private var rec: SpeechRecognizer? = null

    fun start(onResult: (String) -> Unit, fail: (String) -> Unit) {
        stop()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            fail("Is phone me speech recognition available nahi hai")
            return
        }
        rec = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) fail("Kuch sunai nahi diya") else onResult(t)
                }
                override fun onError(error: Int) = fail("Mic error code $error, dobara try karo")
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            )
        }
    }

    fun stop() {
        rec?.destroy()
        rec = null
    }
}
