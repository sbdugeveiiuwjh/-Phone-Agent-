package com.phoneagent
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("p", 0)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { col.addView(it) }
        col.addView(TextView(this).apply { text = "Phone Agent (Gemini)"; textSize = 22f })
        val key = EditText(this).apply { hint = "Gemini API key"; setText(p.getString("k", "")); setSingleLine() }
        col.addView(key)
        btn("1. Key save karo") { p.edit().putString("k", key.text.toString().trim()).apply(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() }
        btn("2. Mic permission do") { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1) }
        btn("3. Accessibility ON karo (Phone Agent)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        col.addView(TextView(this).apply { text = "\nON hote hi 🎤 bubble kisi bhi app par dikhega. Tap karke boliye." })
        val cmd = EditText(this).apply { hint = "Ya yaha type karke command do" }
        col.addView(cmd)
        btn("Run") {
            val svc = AgentService.inst
            if (svc == null) Toast.makeText(this, "Pehle Accessibility ON karo", Toast.LENGTH_LONG).show()
            else { Agent.run(svc, cmd.text.toString()); moveTaskToBack(true) }
        }
        setContentView(ScrollView(this).apply { addView(col, ViewGroup.LayoutParams(-1, -2)) })
    }
}
