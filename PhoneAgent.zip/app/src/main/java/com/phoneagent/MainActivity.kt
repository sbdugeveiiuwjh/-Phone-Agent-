package com.phoneagent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.phoneagent.brain.AgentLoop
import com.phoneagent.brain.ClaudeClient
import com.phoneagent.safety.ConfirmGate
import com.phoneagent.voice.SpeechInput
import com.phoneagent.voice.SpeechOutput
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AgentApp() } }
    }
}

data class Msg(val role: String, val text: String)

private fun isA11yEnabled(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
    return s?.contains(ctx.packageName) == true
}

@Composable
fun AgentApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf<Msg>() }
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(Prefs.apiKey(context).isBlank()) }
    var apiKey by remember { mutableStateOf(Prefs.apiKey(context)) }
    var model by remember { mutableStateOf(Prefs.model(context)) }

    val tts = remember { SpeechOutput(context) }
    val stt = remember { SpeechInput(context) }
    val loop = remember {
        AgentLoop(
            context.applicationContext,
            ClaudeClient({ Prefs.apiKey(context) }, { Prefs.model(context) })
        ) { messages.add(Msg("log", it)) }
    }
    val pending by ConfirmGate.pending.collectAsState()
    val a11yOn = isA11yEnabled(context)

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    fun submit(text: String) {
        if (text.isBlank() || busy) return
        if (Prefs.apiKey(context).isBlank()) {
            messages.add(Msg("log", "Pehle Settings me API key daalo"))
            showSettings = true
            return
        }
        messages.add(Msg("user", text))
        input = ""
        busy = true
        scope.launch {
            try {
                val reply = loop.run(text)
                messages.add(Msg("agent", reply))
                tts.speak(reply)
            } catch (e: Exception) {
                messages.add(Msg("log", "Error: ${e.message}"))
            } finally {
                busy = false
            }
        }
    }

    fun startListen() {
        listening = true
        stt.start(
            onResult = { listening = false; submit(it) },
            fail = { listening = false; messages.add(Msg("log", it)) }
        )
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startListen() else messages.add(Msg("log", "Mic permission chahiye"))
    }

    Column(Modifier.padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Phone Agent", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { showSettings = !showSettings }) { Text("Settings") }
        }

        if (showSettings) {
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = apiKey, onValueChange = { apiKey = it },
                        label = { Text("Anthropic API key") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = model, onValueChange = { model = it },
                        label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = {
                        Prefs.setApiKey(context, apiKey); Prefs.setModel(context, model); showSettings = false
                    }) { Text("Save") }
                    Text(if (a11yOn) "Phone control: ON ✅" else "Phone control: OFF ❌")
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }) { Text("Accessibility settings kholo") }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(messages.toList()) { m ->
                val color = when (m.role) {
                    "user" -> MaterialTheme.colorScheme.primaryContainer
                    "agent" -> MaterialTheme.colorScheme.secondaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                Card(colors = CardDefaults.cardColors(containerColor = color), modifier = Modifier.fillMaxWidth()) {
                    Text(m.text, Modifier.padding(10.dp))
                }
            }
        }

        if (busy) Text("Agent kaam kar raha hai…", Modifier.padding(vertical = 4.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                placeholder = { Text("Kuch bolo ya likho…") },
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) startListen() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }, enabled = !busy) { Text(if (listening) "👂" else "🎤") }
            Button(onClick = { submit(input) }, enabled = !busy) { Text("➤") }
        }
    }

    pending?.let { msg ->
        AlertDialog(
            onDismissRequest = { ConfirmGate.answer(false) },
            title = { Text("Permission chahiye") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { ConfirmGate.answer(true) }) { Text("Haan") } },
            dismissButton = { TextButton(onClick = { ConfirmGate.answer(false) }) { Text("Nahi") } }
        )
    }
}
