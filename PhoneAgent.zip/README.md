# Phone Agent (Android)

Bolo -> AI samjhe -> phone khud chalaye. Coding/file editing bhi.

## Chalane ke steps
1. Computer par **Android Studio** install karo, phir `File > Open` se is folder ko kholo. Gradle sync hone do.
2. Phone me USB debugging ON karke **Run** dabao (ya `Build > Build APK`).
3. App kholo > Settings me **Anthropic API key** daalo > Save.
4. "Accessibility settings kholo" > **Phone Agent** ko ON karo (isse hi tap/scroll/type chalta hai).
5. Mic dabao aur bolo: "WhatsApp kholo", "7 baje ka alarm lagao", "todo.py me ek function jodo".

## Structure
- `brain/` Claude API, AgentLoop (plan-action-check), Tools
- `control/` AccessibilityService (tap/scroll/type), app kholna, call/SMS/alarm
- `coding/` FileEditor (workspace folder: `Android/data/com.phoneagent/files/workspace`)
- `voice/` bolna -> text, jawab bolna
- `safety/` ConfirmGate (pay/send/delete/call se pehle permission)

## Dhyan rakho
- API key phone me save hoti hai: sirf personal use ke liye. Public app ke liye apna backend proxy lagao.
- Coding sirf workspace folder ke andar hoti hai (safety ke liye).
- Banking/UPI apps secure screen ki wajah se screen read nahi hone dete.
- iPhone par yeh possible nahi hai.

## Aage ke upgrades
Floating mic bubble (overlay), foreground service (background me chalne ke liye), wake word, GitHub push.
